<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Profil Guru | SDN Rejosari 03</title>

    <link rel="stylesheet" href="{{ asset('css/profil-guru.css') }}">
</head>

<body class="profil-guru-page">
    <main class="profil-guru">
        <header class="profil-guru__intro">
            <p class="profil-guru__label">SDN REJOSARI 03</p>

            <h1>Mengenal Guru dan <span>Staf Kami</span></h1>

            <p class="profil-guru__description">
                Mengenal para pendidik dan tenaga kependidikan
                yang mendampingi kegiatan belajar di SDN Rejosari 03.
            </p>

            <a class="profil-guru__button" href="#daftar-guru">
                Lihat Daftar Guru
                <span aria-hidden="true">↓</span>
            </a>
        </header>

        <section
            class="profil-guru__section"
            id="daftar-guru"
            aria-labelledby="judul-daftar-guru"
        >
            <div class="profil-guru__section-heading">
                <p class="profil-guru__label">TENAGA PENDIDIK</p>
                <h2 id="judul-daftar-guru">Kepala Sekolah dan Guru</h2>
                <p>
                    Berkenalan dengan kepala sekolah dan guru
                    SDN Rejosari 03.
                </p>
            </div>

            <div class="profil-guru__grid">
                <article class="profil-guru__card">
                    <img
                        class="profil-guru__photo"
                        src="{{ asset('images/guru/suparno.jpg') }}"
                        alt="Foto Suparno"
                        width="600"
                        height="750"
                    >

                    <div class="profil-guru__card-content">
                        <p class="profil-guru__role">Kepala Sekolah</p>
                        <h3>Suparno</h3>
                        <p class="profil-guru__school">SDN Rejosari 03</p>
                    </div>
                </article>

                <article class="profil-guru__card">
                    <img
                        class="profil-guru__photo"
                        src="{{ asset('images/guru/dining-nastiti.jpeg') }}"
                        alt="Foto Dining Nastiti"
                        width="600"
                        height="750"
                        loading="lazy"
                    >

                    <div class="profil-guru__card-content">
                        <p class="profil-guru__role">Guru Kelas 1A</p>
                        <h3>Dining Nastiti</h3>
                        <p class="profil-guru__school">SDN Rejosari 03</p>
                    </div>
                </article>

                <article class="profil-guru__card">
                    <img
                        class="profil-guru__photo"
                        src="{{ asset('images/guru/kiky-dialisa.jpg') }}"
                        alt="Foto Kiky Dialisa"
                        width="600"
                        height="750"
                        loading="lazy"
                    >

                    <div class="profil-guru__card-content">
                        <p class="profil-guru__role">Guru Kelas 1B</p>
                        <h3>Kiky Dialisa</h3>
                        <p class="profil-guru__school">SDN Rejosari 03</p>
                    </div>
                </article>

                <article class="profil-guru__card">
                    <img
                        class="profil-guru__photo"
                        src="{{ asset('images/guru/didik-sutardi.jpeg') }}"
                        alt="Foto Didik Sutardi"
                        width="600"
                        height="750"
                        loading="lazy"
                    >

                    <div class="profil-guru__card-content">
                        <p class="profil-guru__role">Guru Kelas 2A</p>
                        <h3>Didik Sutardi</h3>
                        <p class="profil-guru__school">SDN Rejosari 03</p>
                    </div>
                </article>
            </div>
        </section>
    </main>
</body>
</html>